This program tests the quick sorting algirithm for it's speed
  it runs the quick sort 3 times for every one sze of any array to check. 
  This is because for that size it test the assending verssion, 
  decending version, and when the numbers are randomly sorted in the array.
  
The program does not take any user input but if you wish to chenge the scale/length
  of the arrays it checks (and amount of them) You can do so by editing the 
  top of the program, len and length aray.