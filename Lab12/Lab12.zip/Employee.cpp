#include "Employee.h"

Employee::Employee(std::string empName, double empRate){
  name=empName;
  payRate = empRate;
}
double Employee::pay(){
  return payRate;
}
void Employee::print() const{
  std::cout<<"Employee Name:"<<name<<" payRate:"<<payRate<<std::endl;
}
