// Executive(double,std::string);
// void setBonus(double);
// double pay();
// void print();
#include"Executive.h"

Executive::Executive(std::string n, double p):Employee(n,p){
  bonus=0;
}

void Executive::setBonus(double b){
  bonus=b;
}

double Executive::pay(){
  double Bonus=bonus;
  bonus=0;
  return payRate+Bonus;
}

void Executive::print() const{
      std::cout<<"Name:"<<name<<" payRate:"<<payRate<<" Bonus:"<<bonus<<std::endl;
}
