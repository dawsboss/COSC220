This program is the electronic version the towers of hanoi.
  In this game your goal is to get all the "disks"
  int a pyrimid shape. Although you can only move one disk at a time.
  You also are not allowed to put a bigger disk on top of a smaller disk.

In order to start you must call make and then ./main #
  The number must be between 2-10 for the program to run properly.

The program will ask you to either enter what tower you would like
  to pop from and then where you would like it to push to.
  If you do not follow the rules the program will catch it
  and warn you. There is also another feature to where if you put -1
  (where it asks what you would like to pop) it will give
  you the answer of how to solve the version of the problem
  you made for yourself(Not it will not move any disks for you).


This program runs off of Stacks but linked list stacks.
  In that it uses linked list but in the Stack form, First in
  last out.
